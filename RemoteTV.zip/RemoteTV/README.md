# Remote TV (Xiaomi TV A 55″ / Google TV)

Aplikasi remote Android untuk TV Xiaomi A 55″ (Google TV), terhubung lewat Wi-Fi.

## Fitur versi 0.1
- Pairing dengan kode 6 karakter yang muncul di layar TV (cukup sekali)
- Remote lengkap: Power, Input, Cari, Menu, D-pad + OK, Kembali, Beranda, Putar/Jeda, Volume, Bisukan, Channel
- Tahan tombol volume/panah untuk mengulang otomatis
- Touchpad: geser untuk navigasi, ketuk = OK, tahan = menu
- Keyboard: ketik di HP, teks langsung muncul di TV; ketik suara (bahasa Indonesia); Tempel, Hapus semua, @gmail.com
- Pindah otomatis ke layar keyboard saat TV membuka kolom teks
- Pintasan yang bisa diatur: buka aplikasi, satu tombol, ketik teks, dan makro (beberapa langkah + jeda)
- Tampilan khusus layar luar Galaxy Z Flip 7 (remote ringkas, pintasan, cari dengan suara)

## Cara mendapatkan APK lewat GitHub
1. Buat akun di github.com (gratis), lalu buat repository baru (mis. `remote-tv`).
2. Ekstrak file zip ini di laptop. Di halaman repository, pilih **Add file › Upload files**,
   lalu seret SEMUA isi folder `RemoteTV` (termasuk folder `.github`) ke halaman itu. Klik **Commit changes**.
3. Buka tab **Actions**. Proses "Build APK" berjalan otomatis (sekitar 5–10 menit).
4. Setelah centang hijau, buka halaman **Releases** (menu kanan di halaman utama repository).
   Unduh `app-release.apk` dari HP, lalu pasang (izinkan "pasang dari sumber tidak dikenal").

Setiap kali kode diubah dan di-upload ulang, GitHub membangun versi baru yang bisa dipasang menimpa versi lama.

## Memakai di layar luar Galaxy Z Flip 7
Samsung hanya mengizinkan aplikasi tertentu di layar luar. Untuk aplikasi lain:
Galaxy Store › pasang **Good Lock** › modul **MultiStar** › **I ♡ Galaxy Foldable** › **Launcher Widget**,
lalu aktifkan "Remote TV". Saat HP ditutup, aplikasi otomatis memakai tampilan layar luar.

## Kalau ada masalah
- TV tidak ditemukan: pastikan HP & TV di Wi-Fi yang sama, atau masukkan alamat IP TV secara manual.
- Teks tidak muncul di TV: di layar Keyboard, nyalakan **Mode cadangan**.
- Kalau build di GitHub gagal (tanda silang merah): buka prosesnya, salin pesan error, kirim ke Claude.
