package id.putricindy.remotetv

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import id.putricindy.remotetv.data.Prefs
import id.putricindy.remotetv.data.ShortcutStore
import id.putricindy.remotetv.net.CertManager
import id.putricindy.remotetv.net.RemoteClient
import id.putricindy.remotetv.net.TvDiscovery
import id.putricindy.remotetv.ui.AppRoot
import id.putricindy.remotetv.ui.RemoteTheme

class RemoteApp : Application() {
    lateinit var prefs: Prefs
        private set
    lateinit var certs: CertManager
        private set
    lateinit var remote: RemoteClient
        private set
    lateinit var store: ShortcutStore
        private set
    lateinit var discovery: TvDiscovery
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs(this)
        certs = CertManager(this)
        remote = RemoteClient(certs, prefs)
        store = ShortcutStore(this)
        discovery = TvDiscovery(this)
    }

    companion object {
        lateinit var instance: RemoteApp
            private set
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RemoteTheme {
                AppRoot()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        RemoteApp.instance.remote.ensureConnected()
    }
}
