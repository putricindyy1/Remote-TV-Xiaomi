package id.putricindy.remotetv.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Kode tombol Android yang dikirim ke TV. */
object Key {
    const val HOME = 3
    const val BACK = 4
    const val UP = 19
    const val DOWN = 20
    const val LEFT = 21
    const val RIGHT = 22
    const val CENTER = 23
    const val VOL_UP = 24
    const val VOL_DOWN = 25
    const val POWER = 26
    const val ENTER = 66
    const val DEL = 67
    const val MENU = 82
    const val SEARCH = 84
    const val PLAY_PAUSE = 85
    const val NEXT = 87
    const val PREV = 88
    const val MUTE = 164
    const val CH_UP = 166
    const val CH_DOWN = 167
    const val SETTINGS = 176
    const val INPUT = 178
    const val ASSIST = 219
    const val SLEEP = 223
    const val HDMI1 = 243
    const val HDMI2 = 244
    const val HDMI3 = 245
}

data class KeyOption(val code: Int, val label: String)

val KEY_OPTIONS = listOf(
    KeyOption(Key.POWER, "Power"),
    KeyOption(Key.HOME, "Beranda"),
    KeyOption(Key.BACK, "Kembali"),
    KeyOption(Key.UP, "Atas"),
    KeyOption(Key.DOWN, "Bawah"),
    KeyOption(Key.LEFT, "Kiri"),
    KeyOption(Key.RIGHT, "Kanan"),
    KeyOption(Key.CENTER, "OK"),
    KeyOption(Key.VOL_UP, "Volume naik"),
    KeyOption(Key.VOL_DOWN, "Volume turun"),
    KeyOption(Key.MUTE, "Bisukan"),
    KeyOption(Key.CH_UP, "Channel naik"),
    KeyOption(Key.CH_DOWN, "Channel turun"),
    KeyOption(Key.PLAY_PAUSE, "Putar/Jeda"),
    KeyOption(Key.NEXT, "Berikutnya"),
    KeyOption(Key.PREV, "Sebelumnya"),
    KeyOption(Key.MENU, "Menu"),
    KeyOption(Key.SETTINGS, "Pengaturan TV"),
    KeyOption(Key.INPUT, "Input"),
    KeyOption(Key.HDMI1, "HDMI 1"),
    KeyOption(Key.HDMI2, "HDMI 2"),
    KeyOption(Key.HDMI3, "HDMI 3"),
    KeyOption(Key.SEARCH, "Cari"),
    KeyOption(Key.ASSIST, "Asisten Google"),
    KeyOption(Key.SLEEP, "Tidur (layar mati)"),
    KeyOption(Key.ENTER, "Enter")
)

fun keyLabel(code: Int): String = KEY_OPTIONS.firstOrNull { it.code == code }?.label ?: "Tombol $code"

data class AppPreset(val label: String, val link: String)

val APP_PRESETS = listOf(
    AppPreset("YouTube", "https://www.youtube.com"),
    AppPreset("Netflix", "https://www.netflix.com/title"),
    AppPreset("Prime Video", "https://app.primevideo.com"),
    AppPreset("YouTube Kids", "market://launch?id=com.google.android.youtube.tvkids"),
    AppPreset("Spotify", "market://launch?id=com.spotify.tv.android")
)

fun appLabel(link: String): String =
    APP_PRESETS.firstOrNull { it.link == link }?.label
        ?: if (link.contains("id=")) link.substringAfter("id=") else link

/** Satu langkah pintasan. type: KEY, DELAY, APP, TEXT */
data class Step(
    val type: String,
    val code: Int = 0,
    val repeat: Int = 1,
    val ms: Long = 0,
    val text: String = ""
)

fun delayLabel(ms: Long): String {
    val s = ms / 1000
    return if (s >= 60 && s % 60 == 0L) "${s / 60} menit" else "$s detik"
}

fun Step.describe(): String = when (type) {
    "KEY" -> keyLabel(code) + if (repeat > 1) " × $repeat" else ""
    "DELAY" -> "Jeda " + delayLabel(ms)
    "APP" -> "Buka " + appLabel(text)
    "TEXT" -> "Ketik \"$text\""
    else -> type
}

data class Shortcut(
    val id: String,
    val name: String,
    val icon: String,
    val color: Long,
    val steps: List<Step>
)

fun Shortcut.subtitle(): String = when {
    steps.size == 1 && steps[0].type == "APP" -> "Buka aplikasi"
    steps.size == 1 && steps[0].type == "KEY" -> "Satu tombol"
    steps.size == 1 && steps[0].type == "TEXT" -> "Kirim teks"
    else -> "Makro · ${steps.size} langkah"
}

val PALETTE = listOf(0xFFFF6B6BL, 0xFFFFA36BL, 0xFFB9A6FFL, 0xFF6CB8FFL, 0xFF5FD9A8L)
val ICON_NAMES = listOf("play", "movie", "moon", "input", "child", "music", "star", "tv")

class ShortcutStore(context: Context) {
    private val sp = context.getSharedPreferences("shortcuts", Context.MODE_PRIVATE)
    val items = MutableStateFlow(load())

    private fun load(): List<Shortcut> {
        val raw = sp.getString("list", null) ?: return defaults()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i -> fromJson(arr.getJSONObject(i)) }
        } catch (e: Exception) {
            defaults()
        }
    }

    private fun persist(list: List<Shortcut>) {
        items.value = list
        val arr = JSONArray()
        list.forEach { arr.put(toJson(it)) }
        sp.edit().putString("list", arr.toString()).apply()
    }

    fun upsert(s: Shortcut) {
        val list = items.value.toMutableList()
        val i = list.indexOfFirst { it.id == s.id }
        if (i >= 0) list[i] = s else list.add(s)
        persist(list)
    }

    fun delete(id: String) = persist(items.value.filterNot { it.id == id })

    fun move(id: String, delta: Int) {
        val list = items.value.toMutableList()
        val i = list.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= list.size) return
        val tmp = list[i]
        list[i] = list[j]
        list[j] = tmp
        persist(list)
    }

    private fun toJson(s: Shortcut): JSONObject {
        val steps = JSONArray()
        s.steps.forEach {
            steps.put(
                JSONObject()
                    .put("type", it.type).put("code", it.code).put("repeat", it.repeat)
                    .put("ms", it.ms).put("text", it.text)
            )
        }
        return JSONObject().put("id", s.id).put("name", s.name).put("icon", s.icon)
            .put("color", s.color).put("steps", steps)
    }

    private fun fromJson(o: JSONObject): Shortcut {
        val arr = o.getJSONArray("steps")
        val steps = (0 until arr.length()).map { i ->
            val s = arr.getJSONObject(i)
            Step(
                s.getString("type"), s.optInt("code"), s.optInt("repeat", 1),
                s.optLong("ms"), s.optString("text")
            )
        }
        return Shortcut(o.getString("id"), o.getString("name"), o.optString("icon", "star"), o.getLong("color"), steps)
    }

    private fun defaults() = listOf(
        Shortcut("yt", "YouTube", "play", PALETTE[0], listOf(Step("APP", text = "https://www.youtube.com"))),
        Shortcut("nf", "Netflix", "movie", PALETTE[1], listOf(Step("APP", text = "https://www.netflix.com/title"))),
        Shortcut(
            "sleep", "Mode Tidur", "moon", PALETTE[2],
            listOf(Step("KEY", code = Key.HOME), Step("DELAY", ms = 1000), Step("KEY", code = Key.VOL_DOWN, repeat = 5))
        ),
        Shortcut("hdmi1", "HDMI 1", "input", PALETTE[3], listOf(Step("KEY", code = Key.HDMI1)))
    )
}

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    var lastHost: String?
        get() = sp.getString("host", null)
        set(v) {
            sp.edit().putString("host", v).apply()
        }

    var lastName: String
        get() = sp.getString("name", null) ?: "Xiaomi TV"
        set(v) {
            sp.edit().putString("name", v).apply()
        }

    var keyMode: Boolean
        get() = sp.getBoolean("keyMode", false)
        set(v) {
            sp.edit().putBoolean("keyMode", v).apply()
        }

    val grid = MutableStateFlow(sp.getBoolean("grid", false))

    fun setGrid(v: Boolean) {
        grid.value = v
        sp.edit().putBoolean("grid", v).apply()
    }
}
