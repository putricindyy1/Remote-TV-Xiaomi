package id.putricindy.remotetv.net

import id.putricindy.remotetv.proto.Framing
import id.putricindy.remotetv.proto.ProtoMsg
import id.putricindy.remotetv.proto.ProtoWriter
import java.io.BufferedInputStream
import java.io.Closeable
import java.io.DataInputStream
import java.io.IOException
import java.io.OutputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import javax.net.ssl.SSLSocket

/**
 * Pairing dengan Google TV / Android TV (port 6467).
 * Langkah: start() -> TV menampilkan kode 6 karakter -> finish(kode).
 */
class PairingSession(private val host: String, private val certs: CertManager) : Closeable {

    class WrongCode : Exception("Kode salah")
    class PairingException(msg: String) : Exception(msg)

    private var socket: SSLSocket? = null
    private lateinit var input: DataInputStream
    private lateinit var output: OutputStream

    fun start(clientName: String) {
        val s = certs.sslContext().socketFactory.createSocket() as SSLSocket
        s.connect(InetSocketAddress(host, PORT_PAIRING), 6000)
        s.soTimeout = 20000
        s.startHandshake()
        socket = s
        input = DataInputStream(BufferedInputStream(s.inputStream))
        output = s.outputStream

        // 1. Permintaan pairing
        send { message(10) { string(1, "atvremote"); string(2, clientName) } }
        expect(11)
        // 2. Opsi: kode heksadesimal 6 karakter, HP sebagai pengirim input
        send {
            message(20) {
                message(1) { varint(1, ENCODING_HEX); varint(2, 6) }
                varint(3, ROLE_INPUT)
            }
        }
        expect(20)
        // 3. Konfigurasi
        send {
            message(30) {
                message(1) { varint(1, ENCODING_HEX); varint(2, 6) }
                varint(2, ROLE_INPUT)
            }
        }
        expect(31)
        // Sekarang TV menampilkan kode.
        s.soTimeout = 0
    }

    fun finish(code: String) {
        val s = socket ?: throw PairingException("Pairing belum dimulai")
        val clean = code.trim().uppercase()
        if (clean.length != 6) throw WrongCode()
        val serverCert = s.session.peerCertificates.firstOrNull() as? X509Certificate
            ?: throw PairingException("Sertifikat TV tidak terbaca")
        val client = certs.certificate.publicKey as RSAPublicKey
        val server = serverCert.publicKey as RSAPublicKey

        val md = MessageDigest.getInstance("SHA-256")
        md.update(unsigned(client.modulus))
        md.update(unsigned(client.publicExponent))
        md.update(unsigned(server.modulus))
        md.update(unsigned(server.publicExponent))
        md.update(hexToBytes(clean.substring(2)))
        val hash = md.digest()
        val check = clean.substring(0, 2).toInt(16)
        if ((hash[0].toInt() and 0xFF) != check) throw WrongCode()

        s.soTimeout = 20000
        send { message(40) { bytes(1, hash) } }
        expect(41)
    }

    private fun send(block: ProtoWriter.() -> Unit) {
        val w = ProtoWriter()
        w.varint(1, 2)    // protocol_version
        w.varint(2, 200)  // status OK
        w.block()
        Framing.write(output, w.toByteArray())
    }

    private fun expect(field: Int): ProtoMsg {
        val m = ProtoMsg.parse(Framing.read(input))
        val status = m.varint(2) ?: 0L
        if (status == 402L) throw WrongCode()
        if (status != 200L) throw PairingException("TV menolak (status $status)")
        if (!m.has(field)) throw IOException("Balasan TV tidak terduga")
        return m
    }

    override fun close() {
        try {
            socket?.close()
        } catch (e: Exception) {
        }
        socket = null
    }

    companion object {
        const val PORT_PAIRING = 6467
        private const val ENCODING_HEX = 3
        private const val ROLE_INPUT = 1

        private fun unsigned(b: BigInteger): ByteArray {
            val a = b.toByteArray()
            return if (a.size > 1 && a[0] == 0.toByte()) a.copyOfRange(1, a.size) else a
        }

        private fun hexToBytes(hex: String): ByteArray =
            ByteArray(hex.length / 2) { i -> hex.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }
}
