package id.putricindy.remotetv.net

import android.os.Build
import id.putricindy.remotetv.data.Key
import id.putricindy.remotetv.data.Prefs
import id.putricindy.remotetv.data.Shortcut
import id.putricindy.remotetv.proto.Framing
import id.putricindy.remotetv.proto.ProtoMsg
import id.putricindy.remotetv.proto.proto
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.EOFException
import java.io.IOException
import java.net.ConnectException
import java.net.InetSocketAddress
import java.net.NoRouteToHostException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.Executors
import javax.net.ssl.SSLException
import javax.net.ssl.SSLSocket

/** Koneksi remote ke TV (port 6466): tombol, teks, dan buka aplikasi. */
class RemoteClient(private val certs: CertManager, private val prefs: Prefs) {

    sealed interface State {
        data object Idle : State
        data object Connecting : State
        data object Connected : State
        data object NeedsPairing : State
        data class Error(val message: String) : State
    }

    val state = MutableStateFlow<State>(State.Idle)
    val deviceName = MutableStateFlow(prefs.lastName)
    /** Dipicu saat TV membuka kolom teks (keyboard). */
    val imeRequests = MutableSharedFlow<Unit>(extraBufferCapacity = 4)

    /** Mode cadangan: kirim teks huruf per huruf sebagai tombol. */
    @Volatile var forceKeyMode: Boolean = prefs.keyMode

    var currentHost: String? = prefs.lastHost
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val writer = Executors.newSingleThreadExecutor()

    @Volatile private var socket: SSLSocket? = null
    @Volatile private var gen = 0
    @Volatile private var imeCounter = 0
    @Volatile private var fieldCounter = 0
    @Volatile private var imeActive = false
    private var lastText = ""

    fun connect(host: String, name: String) {
        val my = synchronized(this) {
            gen += 1
            gen
        }
        val old = socket
        socket = null
        currentHost = host
        deviceName.value = name
        state.value = State.Connecting
        scope.launch {
            try {
                old?.close()
            } catch (e: Exception) {
            }
            runConnection(my, host, name)
        }
    }

    fun reconnect() {
        val h = currentHost ?: prefs.lastHost ?: return
        connect(h, deviceName.value)
    }

    fun ensureConnected() {
        val s = state.value
        if (s == State.Idle || s is State.Error) reconnect()
    }

    private fun runConnection(my: Int, host: String, name: String) {
        var configured = false
        try {
            val s = certs.sslContext().socketFactory.createSocket() as SSLSocket
            s.connect(InetSocketAddress(host, PORT_REMOTE), 6000)
            s.soTimeout = 0
            s.startHandshake()
            if (my != gen) {
                s.close()
                return
            }
            socket = s
            val input = DataInputStream(BufferedInputStream(s.inputStream))
            while (my == gen) {
                val msg = ProtoMsg.parse(Framing.read(input))
                when {
                    msg.has(1) -> {
                        send(configureReply())
                        configured = true
                        prefs.lastHost = host
                        prefs.lastName = name
                        if (my == gen) state.value = State.Connected
                    }
                    msg.has(2) -> send(proto { message(2) { varint(1, FEATURES) } })
                    msg.has(8) -> {
                        val v = msg.msg(8)?.varint(1) ?: 0L
                        send(proto { message(9) { varint(1, v) } })
                    }
                    msg.has(20) -> {
                        msg.msg(20)?.msg(2)?.varint(1)?.let { fieldCounter = it.toInt() }
                        imeActive = true
                    }
                    msg.has(21) -> {
                        val b = msg.msg(21)
                        b?.varint(1)?.let { imeCounter = it.toInt() }
                        b?.varint(2)?.let { fieldCounter = it.toInt() }
                        imeActive = true
                    }
                    msg.has(22) -> {
                        msg.msg(22)?.msg(2)?.varint(1)?.let { fieldCounter = it.toInt() }
                        imeActive = true
                        lastText = ""
                        imeRequests.tryEmit(Unit)
                    }
                }
            }
        } catch (e: Exception) {
            if (my != gen) return
            socket = null
            state.value = when {
                e is ConnectException || e is SocketTimeoutException ||
                    e is NoRouteToHostException || e is UnknownHostException ->
                    State.Error("TV tidak bisa dihubungi. Pastikan TV menyala dan satu Wi-Fi dengan HP.")
                !configured && (e is SSLException || e is EOFException || e is SocketException) ->
                    State.NeedsPairing
                else -> State.Error("Koneksi terputus.")
            }
        }
    }

    private fun configureReply(): ByteArray = proto {
        message(1) {
            varint(1, FEATURES)
            message(2) {
                string(1, Build.MODEL ?: "Android")
                string(2, Build.MANUFACTURER ?: "Android")
                varint(3, 1)
                string(4, "1")
                string(5, "atvremote")
                string(6, "1.0.0")
            }
        }
    }

    private fun send(bytes: ByteArray) {
        writer.execute {
            val s = socket ?: return@execute
            try {
                Framing.write(s.outputStream, bytes)
            } catch (e: IOException) {
                if (state.value == State.Connected) {
                    state.value = State.Error("Koneksi terputus.")
                    scope.launch {
                        delay(300)
                        reconnect()
                    }
                }
            }
        }
    }

    // ---------- Perintah ----------

    /** direction: 3 = tekan singkat. */
    fun key(code: Int, direction: Int = 3) {
        send(proto { message(10) { varint(1, code); varint(2, direction) } })
    }

    fun openApp(link: String) {
        send(proto { message(90) { string(1, link) } })
    }

    fun resetText() {
        synchronized(this) { lastText = "" }
    }

    /** Kirim isi kolom teks terbaru ke TV. */
    fun updateText(value: String) {
        synchronized(this) {
            if (imeActive && !forceKeyMode) {
                val pos = value.length - 1
                send(proto {
                    message(21) {
                        varint(1, imeCounter)
                        varint(2, fieldCounter)
                        message(3) {
                            varint(1, 1)
                            message(2) {
                                varint(1, pos)
                                varint(2, pos)
                                string(3, value)
                            }
                        }
                    }
                })
            } else {
                val old = lastText
                var p = 0
                while (p < old.length && p < value.length && old[p] == value[p]) p++
                repeat(old.length - p) { key(Key.DEL) }
                for (c in value.substring(p)) {
                    val k = charKey(c)
                    if (k != null) key(k)
                }
            }
            lastText = value
        }
    }

    fun runShortcut(sc: Shortcut) {
        scope.launch {
            for (st in sc.steps) {
                when (st.type) {
                    "KEY" -> {
                        val n = st.repeat.coerceAtLeast(1)
                        repeat(n) { i ->
                            key(st.code)
                            if (i < n - 1) delay(200)
                        }
                    }
                    "DELAY" -> delay(st.ms)
                    "APP" -> openApp(st.text)
                    "TEXT" -> {
                        resetText()
                        updateText(st.text)
                    }
                }
                delay(150)
            }
        }
    }

    private fun charKey(c: Char): Int? {
        val l = c.lowercaseChar()
        return when {
            l in 'a'..'z' -> 29 + (l - 'a')
            l in '0'..'9' -> 7 + (l - '0')
            l == ' ' -> 62
            l == '.' -> 56
            l == ',' -> 55
            l == '@' -> 77
            l == '-' -> 69
            l == '/' -> 76
            else -> null
        }
    }

    companion object {
        const val PORT_REMOTE = 6466
        private const val FEATURES = 622
    }
}
