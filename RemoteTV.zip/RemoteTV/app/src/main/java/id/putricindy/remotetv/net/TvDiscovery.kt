package id.putricindy.remotetv.net

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import kotlinx.coroutines.flow.MutableStateFlow

data class FoundTv(val name: String, val host: String)

/** Mencari Google TV / Android TV di jaringan Wi-Fi yang sama. */
class TvDiscovery(context: Context) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    val found = MutableStateFlow<List<FoundTv>>(emptyList())

    private var lock: WifiManager.MulticastLock? = null
    private var listener: NsdManager.DiscoveryListener? = null
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false

    @Synchronized
    fun start() {
        stop()
        found.value = emptyList()
        try {
            lock = wifi.createMulticastLock("remotetv").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (e: Exception) {
        }
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onServiceFound(info: NsdServiceInfo) {
                enqueue(info)
            }
            override fun onServiceLost(info: NsdServiceInfo) {
                found.value = found.value.filterNot { it.name == info.serviceName }
            }
        }
        listener = l
        try {
            nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, l)
        } catch (e: Exception) {
            listener = null
        }
    }

    @Synchronized
    fun stop() {
        listener?.let {
            try {
                nsd.stopServiceDiscovery(it)
            } catch (e: Exception) {
            }
        }
        listener = null
        queue.clear()
        resolving = false
        try {
            lock?.release()
        } catch (e: Exception) {
        }
        lock = null
    }

    @Synchronized
    private fun enqueue(info: NsdServiceInfo) {
        queue.addLast(info)
        resolveNext()
    }

    @Synchronized
    private fun resolveNext() {
        if (resolving) return
        val next = queue.removeFirstOrNull() ?: return
        resolving = true
        try {
            @Suppress("DEPRECATION")
            nsd.resolveService(next, object : NsdManager.ResolveListener {
                override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                    done()
                }

                override fun onServiceResolved(info: NsdServiceInfo) {
                    @Suppress("DEPRECATION")
                    val host = info.host?.hostAddress
                    if (host != null) {
                        val tv = FoundTv(info.serviceName, host)
                        found.value = found.value.filterNot { it.host == host } + tv
                    }
                    done()
                }
            })
        } catch (e: Exception) {
            resolving = false
        }
    }

    @Synchronized
    private fun done() {
        resolving = false
        resolveNext()
    }

    companion object {
        private const val SERVICE_TYPE = "_androidtvremote2._tcp"
    }
}
