package id.putricindy.remotetv.proto

import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.EOFException
import java.io.IOException
import java.io.OutputStream

/** Penulis protobuf minimal (cukup untuk protokol remote Android TV / Google TV). */
class ProtoWriter {
    private val out = ByteArrayOutputStream()

    fun varint(field: Int, value: Long) {
        tag(field, 0)
        writeVarint(value)
    }

    fun varint(field: Int, value: Int) {
        varint(field, value.toLong())
    }

    fun bytes(field: Int, value: ByteArray) {
        tag(field, 2)
        writeVarint(value.size.toLong())
        out.write(value)
    }

    fun string(field: Int, value: String) {
        bytes(field, value.toByteArray(Charsets.UTF_8))
    }

    fun message(field: Int, block: ProtoWriter.() -> Unit) {
        val inner = ProtoWriter()
        inner.block()
        bytes(field, inner.toByteArray())
    }

    fun toByteArray(): ByteArray = out.toByteArray()

    private fun tag(field: Int, wire: Int) {
        writeVarint(((field shl 3) or wire).toLong())
    }

    private fun writeVarint(v0: Long) {
        var v = v0
        while (true) {
            if ((v and 0x7FL.inv()) == 0L) {
                out.write(v.toInt())
                return
            }
            out.write(((v and 0x7FL) or 0x80L).toInt())
            v = v ushr 7
        }
    }
}

fun proto(block: ProtoWriter.() -> Unit): ByteArray {
    val w = ProtoWriter()
    w.block()
    return w.toByteArray()
}

/** Pembaca protobuf minimal: menyimpan nilai per nomor field. */
class ProtoMsg private constructor(private val fields: Map<Int, List<Any>>) {

    fun has(field: Int): Boolean = fields.containsKey(field)

    fun varint(field: Int): Long? = fields[field]?.firstOrNull() as? Long

    fun bytes(field: Int): ByteArray? = fields[field]?.firstOrNull() as? ByteArray

    fun string(field: Int): String? = bytes(field)?.toString(Charsets.UTF_8)

    fun msg(field: Int): ProtoMsg? {
        val b = bytes(field) ?: return null
        return try {
            parse(b)
        } catch (e: IOException) {
            null
        }
    }

    companion object {
        fun parse(data: ByteArray): ProtoMsg {
            val map = HashMap<Int, MutableList<Any>>()
            var pos = 0

            fun readVarint(): Long {
                var result = 0L
                var shift = 0
                while (true) {
                    if (pos >= data.size) throw IOException("varint terpotong")
                    val b = data[pos].toInt() and 0xFF
                    pos += 1
                    result = result or ((b and 0x7F).toLong() shl shift)
                    if ((b and 0x80) == 0) return result
                    shift += 7
                    if (shift > 63) throw IOException("varint terlalu panjang")
                }
            }

            while (pos < data.size) {
                val key = readVarint()
                val field = (key ushr 3).toInt()
                val wire = (key and 7L).toInt()
                when (wire) {
                    0 -> map.getOrPut(field) { mutableListOf() }.add(readVarint())
                    2 -> {
                        val len = readVarint().toInt()
                        if (len < 0 || pos + len > data.size) throw IOException("panjang tidak valid")
                        val b = data.copyOfRange(pos, pos + len)
                        pos += len
                        map.getOrPut(field) { mutableListOf() }.add(b)
                    }
                    1 -> pos += 8
                    5 -> pos += 4
                    else -> throw IOException("wire type $wire tidak dikenal")
                }
            }
            return ProtoMsg(map)
        }
    }
}

/** Setiap pesan dikirim dengan awalan panjang (varint). */
object Framing {
    fun write(out: OutputStream, msg: ByteArray) {
        val buf = ByteArrayOutputStream()
        var v = msg.size
        while (v >= 0x80) {
            buf.write((v and 0x7F) or 0x80)
            v = v ushr 7
        }
        buf.write(v)
        buf.write(msg)
        out.write(buf.toByteArray())
        out.flush()
    }

    fun read(input: DataInputStream): ByteArray {
        var len = 0
        var shift = 0
        while (true) {
            val b = input.read()
            if (b < 0) throw EOFException("Koneksi ditutup TV")
            len = len or ((b and 0x7F) shl shift)
            if ((b and 0x80) == 0) break
            shift += 7
            if (shift > 28) throw IOException("frame tidak valid")
        }
        val data = ByteArray(len)
        input.readFully(data)
        return data
    }
}
