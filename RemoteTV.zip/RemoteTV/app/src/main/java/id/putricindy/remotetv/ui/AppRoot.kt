package id.putricindy.remotetv.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.putricindy.remotetv.RemoteApp
import id.putricindy.remotetv.net.RemoteClient

@Composable
fun AppRoot() {
    val app = RemoteApp.instance
    val state by app.remote.state.collectAsState()
    val cfg = LocalConfiguration.current
    // Layar luar Galaxy Z Flip (Flex Window) kecil dan hampir persegi.
    val isCover = cfg.screenWidthDp < 600 && cfg.screenHeightDp < 560

    var tab by rememberSaveable { mutableStateOf("remote") }
    var overlay by rememberSaveable { mutableStateOf(if (app.prefs.lastHost == null) "connect" else "") }
    var editId by rememberSaveable { mutableStateOf("") }
    val coverNow by rememberUpdatedState(isCover)

    // TV membuka kolom teks -> langsung ke layar keyboard.
    LaunchedEffect(Unit) {
        app.remote.imeRequests.collect {
            if (!coverNow) {
                overlay = ""
                tab = "keyboard"
            }
        }
    }
    LaunchedEffect(state) {
        if (state == RemoteClient.State.NeedsPairing && !coverNow) overlay = "connect"
    }

    BackHandler(enabled = !isCover && overlay.isNotEmpty() && !(overlay == "connect" && app.prefs.lastHost == null)) {
        overlay = if (overlay == "edit") "shortcuts" else ""
    }

    Box(Modifier.fillMaxSize().background(C.Bg)) {
        when {
            isCover -> CoverScreen(app)
            overlay == "connect" -> ConnectScreen(
                app,
                canClose = app.prefs.lastHost != null,
                onDone = { overlay = "" }
            )
            overlay == "shortcuts" -> ShortcutsScreen(
                app,
                onBack = { overlay = "" },
                onEdit = { id ->
                    editId = id
                    overlay = "edit"
                }
            )
            overlay == "edit" -> ShortcutEditScreen(
                app,
                id = editId.ifEmpty { null },
                onClose = { overlay = "shortcuts" }
            )
            else -> Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        "touchpad" -> TouchpadScreen(app)
                        "keyboard" -> KeyboardScreen(app)
                        else -> RemoteScreen(
                            app,
                            onOpenConnect = { overlay = "connect" },
                            onAddShortcut = {
                                editId = ""
                                overlay = "edit"
                            },
                            onOpenShortcuts = { overlay = "shortcuts" }
                        )
                    }
                }
                BottomNav(tab) { t ->
                    if (t == "shortcuts") overlay = "shortcuts" else tab = t
                }
            }
        }
    }
}

@Composable
private fun BottomNav(tab: String, onSelect: (String) -> Unit) {
    Column {
        Box(Modifier.fillMaxWidth().height(1.dp).background(C.Border))
        Row(Modifier.fillMaxWidth().background(C.NavBg).padding(top = 10.dp, bottom = 14.dp)) {
            NavItem(Modifier.weight(1f), Icons.Filled.SettingsRemote, "Remote", tab == "remote") { onSelect("remote") }
            NavItem(Modifier.weight(1f), Icons.Filled.TouchApp, "Touchpad", tab == "touchpad") { onSelect("touchpad") }
            NavItem(Modifier.weight(1f), Icons.Filled.Keyboard, "Keyboard", tab == "keyboard") { onSelect("keyboard") }
            NavItem(Modifier.weight(1f), Icons.Filled.Apps, "Pintasan", false) { onSelect("shortcuts") }
        }
    }
}

@Composable
private fun NavItem(modifier: Modifier, icon: ImageVector, label: String, on: Boolean, onClick: () -> Unit) {
    Column(
        modifier.clickable(onClick = onClick).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        val color = if (on) C.Accent else C.Muted
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
        Text(label, color = color, fontSize = 11.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
    }
}
