package id.putricindy.remotetv.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.putricindy.remotetv.RemoteApp
import id.putricindy.remotetv.data.Shortcut
import id.putricindy.remotetv.net.RemoteClient
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

object C {
    val Bg = Color(0xFF101114)
    val Surface = Color(0xFF1C1E23)
    val Surface2 = Color(0xFF262930)
    val Border = Color(0xFF2E3138)
    val Text = Color(0xFFF3F4F6)
    val Muted = Color(0xFFA0A5AE)
    val Accent = Color(0xFFFF7A1A)
    val Green = Color(0xFF3DD68C)
    val Red = Color(0xFFFF6B6B)
    val RedBg = Color(0xFF3A1D1F)
    val NavBg = Color(0xFF16181C)
    val Dashed = Color(0xFF4A4F58)
}

@Composable
fun RemoteTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.Accent,
            onPrimary = C.Bg,
            background = C.Bg,
            onBackground = C.Text,
            surface = C.Surface,
            onSurface = C.Text,
            surfaceVariant = C.Surface2,
            onSurfaceVariant = C.Muted,
            outline = C.Border
        ),
        content = content
    )
}

fun iconFor(name: String): ImageVector = when (name) {
    "play" -> Icons.Filled.PlayArrow
    "movie" -> Icons.Filled.Movie
    "moon" -> Icons.Filled.Bedtime
    "input" -> Icons.Filled.Input
    "child" -> Icons.Filled.ChildCare
    "music" -> Icons.Filled.MusicNote
    "tv" -> Icons.Filled.Tv
    else -> Icons.Filled.Star
}

fun statusOf(s: RemoteClient.State): Pair<String, Color> = when (s) {
    RemoteClient.State.Connected -> "Tersambung · Wi-Fi" to C.Green
    RemoteClient.State.Connecting -> "Menghubungkan…" to C.Muted
    RemoteClient.State.NeedsPairing -> "Perlu dipasangkan" to C.Accent
    is RemoteClient.State.Error -> "Terputus" to C.Red
    RemoteClient.State.Idle -> "Belum tersambung" to C.Muted
}

/** Area yang bisa ditekan. repeat = true: tahan untuk mengulang (volume, panah). */
@Composable
fun PressBox(
    modifier: Modifier,
    description: String,
    repeat: Boolean = false,
    onAction: () -> Unit,
    content: @Composable BoxScope.() -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val action by rememberUpdatedState(onAction)
    val scope = rememberCoroutineScope()
    val input = if (repeat) {
        modifier.pointerInput(Unit) {
            detectTapGestures(onPress = {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                action()
                val job = scope.launch {
                    delay(400)
                    while (true) {
                        action()
                        delay(110)
                    }
                }
                tryAwaitRelease()
                job.cancel()
            })
        }
    } else {
        modifier.clickable {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            action()
        }
    }
    Box(
        input.semantics {
            contentDescription = description
            role = Role.Button
        },
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
fun RoundKey(
    icon: ImageVector,
    description: String,
    size: Dp = 56.dp,
    bg: Color = C.Surface,
    tint: Color = C.Text,
    repeat: Boolean = false,
    onClick: () -> Unit
) {
    PressBox(
        Modifier.size(size).clip(CircleShape).background(bg).border(1.dp, C.Border, CircleShape),
        description, repeat, onClick
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.4f))
    }
}

@Composable
fun LabeledKey(
    icon: ImageVector,
    label: String,
    bg: Color = C.Surface,
    tint: Color = C.Text,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        RoundKey(icon, label, bg = bg, tint = tint, onClick = onClick)
        Text(label, fontSize = 11.sp, color = C.Muted)
    }
}

@Composable
fun DPad(size: Dp, onKey: (Int) -> Unit) {
    Box(Modifier.size(size).clip(CircleShape).background(C.Surface).border(1.dp, C.Border, CircleShape)) {
        val arrow = size * 0.32f
        PressBox(Modifier.align(Alignment.TopCenter).size(arrow), "Atas", true, { onKey(id.putricindy.remotetv.data.Key.UP) }) {
            Icon(Icons.Filled.KeyboardArrowUp, null, tint = C.Text, modifier = Modifier.size(30.dp))
        }
        PressBox(Modifier.align(Alignment.BottomCenter).size(arrow), "Bawah", true, { onKey(id.putricindy.remotetv.data.Key.DOWN) }) {
            Icon(Icons.Filled.KeyboardArrowDown, null, tint = C.Text, modifier = Modifier.size(30.dp))
        }
        PressBox(Modifier.align(Alignment.CenterStart).size(arrow), "Kiri", true, { onKey(id.putricindy.remotetv.data.Key.LEFT) }) {
            Icon(Icons.Filled.KeyboardArrowLeft, null, tint = C.Text, modifier = Modifier.size(30.dp))
        }
        PressBox(Modifier.align(Alignment.CenterEnd).size(arrow), "Kanan", true, { onKey(id.putricindy.remotetv.data.Key.RIGHT) }) {
            Icon(Icons.Filled.KeyboardArrowRight, null, tint = C.Text, modifier = Modifier.size(30.dp))
        }
        PressBox(
            Modifier.align(Alignment.Center).size(size * 0.36f).clip(CircleShape)
                .background(C.Surface2).border(2.dp, C.Accent, CircleShape),
            "OK", false, { onKey(id.putricindy.remotetv.data.Key.CENTER) }
        ) {
            Text("OK", color = C.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

/** Kotak pintasan. sc = null berarti tombol "Tambah". */
@Composable
fun ShortcutTile(sc: Shortcut?, modifier: Modifier = Modifier, box: Dp = 52.dp, onClick: () -> Unit) {
    PressBox(modifier.clip(RoundedCornerShape(12.dp)), sc?.name ?: "Tambah pintasan", false, onClick) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (sc == null) {
                Box(
                    Modifier.size(box).border(1.dp, C.Dashed, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Add, null, tint = C.Muted) }
            } else {
                val col = Color(sc.color)
                Box(
                    Modifier.size(box).clip(RoundedCornerShape(16.dp)).background(col.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) { Icon(iconFor(sc.icon), null, tint = col) }
            }
            Text(
                sc?.name ?: "Tambah", fontSize = 11.sp,
                color = if (sc == null) C.Muted else C.Text,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = C.Muted, letterSpacing = 0.8.sp)
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.Surface)
            .border(1.dp, C.Border, RoundedCornerShape(14.dp)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(10.dp))
                    .background(if (on) C.Accent else Color.Transparent)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (on) C.Bg else C.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun Chip(text: String, icon: ImageVector? = null, onClick: () -> Unit) {
    Row(
        Modifier.height(36.dp).clip(RoundedCornerShape(50)).background(C.Surface)
            .border(1.dp, C.Border, RoundedCornerShape(50)).clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (icon != null) Icon(icon, null, tint = C.Text, modifier = Modifier.size(16.dp))
        Text(text, color = C.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Judul layar + status TV kecil. */
@Composable
fun ScreenHeader(title: String, trailing: (@Composable () -> Unit)? = null) {
    val remote = RemoteApp.instance.remote
    val state by remote.state.collectAsState()
    val name by remote.deviceName.collectAsState()
    val (label, color) = statusOf(state)
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = C.Text)
            Text("$name · $label", fontSize = 12.sp, color = color, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (trailing != null) trailing()
    }
}

/** Mengembalikan fungsi untuk memulai pengenalan suara HP (bahasa Indonesia). */
@Composable
fun rememberVoiceInput(onText: (String) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val callback by rememberUpdatedState(onText)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrBlank()) callback(t)
    }
    return {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Ucapkan yang mau diketik ke TV")
        try {
            launcher.launch(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "Pengetikan suara tidak tersedia di HP ini", Toast.LENGTH_SHORT).show()
        }
    }
}
