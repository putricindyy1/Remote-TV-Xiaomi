package id.putricindy.remotetv.ui

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.putricindy.remotetv.RemoteApp
import id.putricindy.remotetv.net.FoundTv
import id.putricindy.remotetv.net.PairingSession
import id.putricindy.remotetv.net.RemoteClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ConnectScreen(app: RemoteApp, canClose: Boolean, onDone: () -> Unit) {
    val remote = app.remote
    val state by remote.state.collectAsState()
    val found by app.discovery.found.collectAsState()
    val scope = rememberCoroutineScope()

    var target by remember {
        mutableStateOf(
            if (remote.state.value == RemoteClient.State.NeedsPairing)
                remote.currentHost?.let { FoundTv(remote.deviceName.value, it) }
            else null
        )
    }
    // pick, connecting, pairing, code
    var phase by remember { mutableStateOf("pick") }
    var error by remember { mutableStateOf<String?>(null) }
    var code by remember { mutableStateOf("") }
    var manualIp by remember { mutableStateOf("") }
    var session by remember { mutableStateOf<PairingSession?>(null) }

    DisposableEffect(Unit) {
        app.discovery.start()
        onDispose {
            app.discovery.stop()
            val s = session
            if (s != null) Thread { s.close() }.start()
        }
    }

    fun choose(t: FoundTv) {
        target = t
        error = null
        code = ""
        phase = "connecting"
        remote.connect(t.host, t.name)
    }

    fun closeSession() {
        val s = session
        session = null
        if (s != null) Thread { s.close() }.start()
    }

    LaunchedEffect(state, target) {
        val t = target ?: return@LaunchedEffect
        when (val s = state) {
            RemoteClient.State.Connected -> if (phase != "pick") {
                phase = "pick"
                onDone()
            }
            RemoteClient.State.NeedsPairing -> if (phase == "connecting" || phase == "pick") {
                phase = "pairing"
                error = null
                try {
                    val ps = withContext(Dispatchers.IO) {
                        PairingSession(t.host, app.certs).also { it.start(Build.MODEL ?: "HP Android") }
                    }
                    session = ps
                    code = ""
                    phase = "code"
                } catch (e: Exception) {
                    error = "Gagal memulai pairing: " + (e.message ?: e.javaClass.simpleName)
                    phase = "pick"
                }
            }
            is RemoteClient.State.Error -> if (phase == "connecting") {
                error = s.message
                phase = "pick"
            }
            else -> {}
        }
    }

    fun submit() {
        val ps = session ?: return
        val t = target ?: return
        phase = "pairing"
        error = null
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    ps.finish(code)
                    ps.close()
                }
                session = null
                phase = "connecting"
                remote.connect(t.host, t.name)
            } catch (e: PairingSession.WrongCode) {
                error = "Kode salah. Pilih TV lagi untuk mendapat kode baru."
                closeSession()
                phase = "pick"
            } catch (e: Exception) {
                error = "Pairing gagal: " + (e.message ?: e.javaClass.simpleName)
                closeSession()
                phase = "pick"
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            if (canClose) RoundKey(Icons.Filled.ArrowBack, "Kembali", size = 44.dp) {
                closeSession()
                onDone()
            }
            Column {
                Text("Sambungkan ke TV", color = C.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("HP dan TV harus di Wi-Fi yang sama.", color = C.Muted, fontSize = 13.sp)
            }
        }

        when (phase) {
            "code" -> Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(C.Surface)
                    .border(1.dp, C.Border, RoundedCornerShape(18.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Masukkan kode di layar TV", color = C.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "TV ${target?.name ?: ""} sedang menampilkan kode 6 karakter. Cukup sekali, selanjutnya tersambung otomatis.",
                    color = C.Muted, fontSize = 13.sp
                )
                OutlinedTextField(
                    value = code,
                    onValueChange = { v -> code = v.uppercase().filter { it in "0123456789ABCDEF" }.take(6) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = 8.sp, textAlign = TextAlign.Center),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters, keyboardType = KeyboardType.Ascii),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = C.Accent, unfocusedBorderColor = C.Border,
                        focusedTextColor = C.Text, unfocusedTextColor = C.Text, cursorColor = C.Accent
                    )
                )
                Button(
                    onClick = { submit() },
                    enabled = code.length == 6,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)
                ) { Text("Pasangkan", fontWeight = FontWeight.Bold) }
                TextButton(onClick = {
                    closeSession()
                    phase = "pick"
                }) { Text("Batal", color = C.Muted) }
            }

            "pairing", "connecting" -> Row(
                Modifier.fillMaxWidth().padding(vertical = 24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CircularProgressIndicator(Modifier.size(22.dp), color = C.Accent, strokeWidth = 2.dp)
                Text(
                    if (phase == "pairing") "Menunggu TV…" else "Menghubungkan ke ${target?.name ?: "TV"}…",
                    color = C.Text, fontSize = 15.sp
                )
            }

            else -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionLabel("TV DITEMUKAN")
                if (found.isEmpty()) {
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(Modifier.size(18.dp), color = C.Accent, strokeWidth = 2.dp)
                        Text("Mencari TV di jaringan Wi-Fi…", color = C.Muted, fontSize = 13.sp)
                    }
                }
                found.forEach { tv ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.Surface)
                            .border(1.dp, C.Border, RoundedCornerShape(16.dp))
                            .clickable { choose(tv) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(C.Surface2),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Filled.Tv, null, tint = C.Text) }
                        Column(Modifier.weight(1f)) {
                            Text(tv.name, color = C.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(tv.host, color = C.Muted, fontSize = 12.sp)
                        }
                        Text("Pilih", color = C.Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }

                SectionLabel("ATAU MASUKKAN ALAMAT IP TV")
                Text(
                    "Lihat di TV: Setelan › Jaringan & Internet › nama Wi-Fi › Alamat IP.",
                    color = C.Muted, fontSize = 12.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = manualIp,
                        onValueChange = { manualIp = it.trim() },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("192.168.1.10") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = C.Accent, unfocusedBorderColor = C.Border,
                            focusedTextColor = C.Text, unfocusedTextColor = C.Text, cursorColor = C.Accent
                        )
                    )
                    Button(
                        onClick = { choose(FoundTv("TV ($manualIp)", manualIp)) },
                        enabled = manualIp.isNotEmpty(),
                        modifier = Modifier.height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)
                    ) { Text("Sambung") }
                }
            }
        }

        val err = error
        if (err != null) Text(err, color = C.Red, fontSize = 13.sp)
    }
}
