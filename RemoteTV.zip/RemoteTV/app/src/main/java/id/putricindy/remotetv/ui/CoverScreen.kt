package id.putricindy.remotetv.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.putricindy.remotetv.RemoteApp
import id.putricindy.remotetv.data.Key
import id.putricindy.remotetv.net.RemoteClient

/**
 * Tampilan untuk layar luar Galaxy Z Flip 7 (Flex Window).
 * Tiga halaman yang digeser: remote ringkas, pintasan, cari dengan suara.
 * Pojok kiri bawah dikosongkan karena ada kamera.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CoverScreen(app: RemoteApp) {
    val remote = app.remote
    val state by remote.state.collectAsState()
    val name by remote.deviceName.collectAsState()

    if (state != RemoteClient.State.Connected) {
        val (label, color) = statusOf(state)
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterVertically)
        ) {
            Icon(Icons.Filled.Tv, null, tint = C.Text, modifier = Modifier.size(32.dp))
            Text(name, color = C.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(label, color = color, fontSize = 12.sp)
            Button(
                onClick = { remote.reconnect() },
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)
            ) { Text("Sambungkan", fontWeight = FontWeight.Bold) }
            Text("Untuk memilih TV atau pairing, buka HP.", color = C.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
        return
    }

    val pager = rememberPagerState(pageCount = { 3 })
    Box(Modifier.fillMaxSize()) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            when (page) {
                0 -> CoverRemotePage(app)
                1 -> CoverShortcutsPage(app)
                else -> CoverVoicePage(app)
            }
        }
        Row(
            Modifier.align(Alignment.TopCenter).padding(top = 26.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            repeat(3) { i ->
                val on = pager.currentPage == i
                Box(
                    Modifier.height(6.dp).width(if (on) 14.dp else 6.dp).clip(RoundedCornerShape(50))
                        .background(if (on) C.Accent else C.Dashed)
                )
            }
        }
    }
}

@Composable
private fun CoverRemotePage(app: RemoteApp) {
    val remote = app.remote
    val name by remote.deviceName.collectAsState()
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(name, color = C.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Tersambung", color = C.Green, fontSize = 11.sp)
            }
            RoundKey(Icons.Filled.PowerSettingsNew, "Power", size = 48.dp, bg = C.RedBg, tint = C.Red) { remote.key(Key.POWER) }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            DPad(188.dp) { remote.key(it) }
            Spacer(Modifier.weight(1f))
            Column(
                Modifier.width(64.dp).height(188.dp).clip(RoundedCornerShape(50)).background(C.Surface)
                    .border(1.dp, C.Border, RoundedCornerShape(50)).padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                PressBox(Modifier.size(52.dp).clip(CircleShape).background(C.Surface2), "Volume naik", true, { remote.key(Key.VOL_UP) }) {
                    Icon(Icons.Filled.Add, null, tint = C.Text)
                }
                Text("VOL", color = C.Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                PressBox(Modifier.size(52.dp).clip(CircleShape).background(C.Surface2), "Volume turun", true, { remote.key(Key.VOL_DOWN) }) {
                    Icon(Icons.Filled.Remove, null, tint = C.Text)
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.End)) {
            RoundKey(Icons.Filled.ArrowBack, "Kembali", size = 52.dp) { remote.key(Key.BACK) }
            RoundKey(Icons.Filled.VolumeOff, "Bisukan", size = 52.dp) { remote.key(Key.MUTE) }
            RoundKey(Icons.Filled.Home, "Beranda", size = 52.dp) { remote.key(Key.HOME) }
        }
    }
}

@Composable
private fun CoverShortcutsPage(app: RemoteApp) {
    val list by app.store.items.collectAsState()
    Column(
        Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Pintasan", color = C.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        list.take(6).chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { sc ->
                    val col = Color(sc.color)
                    PressBox(
                        Modifier.weight(1f).height(88.dp).clip(RoundedCornerShape(20.dp)).background(col.copy(alpha = 0.18f)),
                        sc.name, false, { app.remote.runShortcut(sc) }
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(iconFor(sc.icon), null, tint = col)
                            Text(sc.name, color = C.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        if (list.isEmpty()) Text("Belum ada pintasan. Atur dari HP.", color = C.Muted, fontSize = 12.sp)
    }
}

@Composable
private fun CoverVoicePage(app: RemoteApp) {
    val remote = app.remote
    var last by remember { mutableStateOf("") }
    val voice = rememberVoiceInput { t ->
        last = t
        remote.resetText()
        remote.updateText(t)
    }
    Column(
        Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Cari di TV", color = C.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Box(
            Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(16.dp)).background(C.Surface)
                .border(1.dp, C.Border, RoundedCornerShape(16.dp)).padding(horizontal = 14.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Text(
                if (last.isEmpty()) "Belum ada teks" else last,
                color = if (last.isEmpty()) C.Muted else C.Text, fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(18.dp, Alignment.CenterHorizontally)
        ) {
            PressBox(Modifier.size(104.dp).clip(CircleShape).background(C.Accent), "Ketuk lalu bicara", false, { voice() }) {
                Icon(Icons.Filled.Mic, null, tint = C.Bg, modifier = Modifier.size(40.dp))
            }
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Chip("Kirim") { remote.key(Key.ENTER) }
                Chip("Hapus") {
                    last = ""
                    remote.updateText("")
                }
            }
        }
        Text(
            "Ketuk lalu bicara. Buka HP untuk keyboard lengkap.",
            color = C.Muted, fontSize = 12.sp, textAlign = TextAlign.End,
            modifier = Modifier.fillMaxWidth().padding(start = 120.dp)
        )
    }
}
