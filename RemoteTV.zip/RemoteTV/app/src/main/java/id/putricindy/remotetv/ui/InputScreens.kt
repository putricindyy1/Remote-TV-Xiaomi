package id.putricindy.remotetv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.putricindy.remotetv.RemoteApp
import id.putricindy.remotetv.data.Key
import kotlin.math.abs

@Composable
fun TouchpadScreen(app: RemoteApp) {
    val remote = app.remote
    val haptic = LocalHapticFeedback.current
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenHeader("Touchpad")
        Box(
            Modifier.fillMaxWidth().weight(1f)
                .clip(RoundedCornerShape(24.dp)).background(C.Surface)
                .border(1.dp, C.Border, RoundedCornerShape(24.dp))
                .pointerInput(Unit) {
                    val step = 56.dp.toPx()
                    var acc = Offset.Zero
                    detectDragGestures(
                        onDragStart = { acc = Offset.Zero },
                        onDrag = { change, drag ->
                            change.consume()
                            acc += drag
                            while (abs(acc.x) > step || abs(acc.y) > step) {
                                if (abs(acc.x) >= abs(acc.y)) {
                                    if (acc.x > 0) {
                                        remote.key(Key.RIGHT)
                                        acc = Offset(acc.x - step, acc.y)
                                    } else {
                                        remote.key(Key.LEFT)
                                        acc = Offset(acc.x + step, acc.y)
                                    }
                                } else {
                                    if (acc.y > 0) {
                                        remote.key(Key.DOWN)
                                        acc = Offset(acc.x, acc.y - step)
                                    } else {
                                        remote.key(Key.UP)
                                        acc = Offset(acc.x, acc.y + step)
                                    }
                                }
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            }
                        }
                    )
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            remote.key(Key.CENTER)
                        },
                        onLongPress = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            remote.key(Key.MENU)
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Box(
                    Modifier.size(64.dp).border(2.dp, C.Accent, CircleShape),
                    contentAlignment = Alignment.Center
                ) { Box(Modifier.size(20.dp).clip(CircleShape).background(C.Accent)) }
                Text("Geser untuk pindah pilihan", color = C.Muted, fontSize = 13.sp)
                Text("Ketuk sekali = OK", color = C.Muted, fontSize = 13.sp)
                Text("Tahan = menu opsi", color = C.Muted, fontSize = 13.sp)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            RoundKey(Icons.Filled.ArrowBack, "Kembali") { remote.key(Key.BACK) }
            RoundKey(Icons.Filled.Home, "Beranda") { remote.key(Key.HOME) }
            RoundKey(Icons.Filled.VolumeDown, "Volume turun", repeat = true) { remote.key(Key.VOL_DOWN) }
            RoundKey(Icons.Filled.VolumeUp, "Volume naik", repeat = true) { remote.key(Key.VOL_UP) }
        }
    }
}

@Composable
fun KeyboardScreen(app: RemoteApp) {
    val remote = app.remote
    var text by rememberSaveable { mutableStateOf("") }
    var keyMode by remember { mutableStateOf(remote.forceKeyMode) }
    val focus = remember { FocusRequester() }
    val clipboard = LocalClipboardManager.current

    fun change(v: String) {
        text = v
        remote.updateText(v)
    }

    val voice = rememberVoiceInput { t -> change(t) }

    LaunchedEffect(Unit) {
        remote.resetText()
        text = ""
        try {
            focus.requestFocus()
        } catch (e: Exception) {
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenHeader("Keyboard") { Chip("Ketik suara", Icons.Filled.Mic) { voice() } }

        SectionLabel("TEKS UNTUK LAYAR TV")
        OutlinedTextField(
            value = text,
            onValueChange = { change(it) },
            modifier = Modifier.fillMaxWidth().focusRequester(focus),
            placeholder = { Text("Ketik di sini, langsung muncul di TV") },
            singleLine = true,
            textStyle = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onAny = { remote.key(Key.ENTER) }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = C.Accent,
                unfocusedBorderColor = C.Border,
                focusedTextColor = C.Text,
                unfocusedTextColor = C.Text,
                cursorColor = C.Accent
            )
        )

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Tempel", Icons.Filled.ContentPaste) {
                val clip = clipboard.getText()?.text
                if (!clip.isNullOrEmpty()) change(text + clip)
            }
            Chip("Hapus semua", Icons.Filled.Close) { change("") }
            Chip("@gmail.com") { change(text + "@gmail.com") }
            Chip(".com") { change(text + ".com") }
        }

        SectionLabel("KONTROL CEPAT")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            RoundKey(Icons.Filled.KeyboardArrowLeft, "Kursor kiri", repeat = true) { remote.key(Key.LEFT) }
            RoundKey(Icons.Filled.KeyboardArrowRight, "Kursor kanan", repeat = true) { remote.key(Key.RIGHT) }
            RoundKey(Icons.Filled.ArrowBack, "Kembali") { remote.key(Key.BACK) }
            RoundKey(Icons.Filled.Home, "Beranda") { remote.key(Key.HOME) }
        }

        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.Surface)
                .border(1.dp, C.Border, RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Mode cadangan", color = C.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Nyalakan kalau teks tidak muncul di TV. Huruf dikirim satu per satu.",
                    color = C.Muted, fontSize = 12.sp
                )
            }
            Switch(
                checked = keyMode,
                onCheckedChange = {
                    keyMode = it
                    remote.forceKeyMode = it
                    app.prefs.keyMode = it
                    remote.resetText()
                    text = ""
                },
                colors = SwitchDefaults.colors(checkedTrackColor = C.Accent, checkedThumbColor = C.Bg)
            )
        }

        Spacer(Modifier.height(4.dp))
        Button(
            onClick = { remote.key(Key.ENTER) },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(50),
            colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)
        ) {
            Text("Kirim / Cari", fontSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}
