package id.putricindy.remotetv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.putricindy.remotetv.RemoteApp
import id.putricindy.remotetv.data.Key
import id.putricindy.remotetv.data.Shortcut
import id.putricindy.remotetv.net.RemoteClient

@Composable
fun RemoteScreen(
    app: RemoteApp,
    onOpenConnect: () -> Unit,
    onAddShortcut: () -> Unit,
    onOpenShortcuts: () -> Unit
) {
    val remote = app.remote
    val shortcuts by app.store.items.collectAsState()
    val grid by app.prefs.grid.collectAsState()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            DeviceChip(remote, onOpenConnect)
            Spacer(Modifier.weight(1f))
            RoundKey(Icons.Filled.Refresh, "Sambungkan ulang", size = 44.dp) { remote.reconnect() }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            LabeledKey(Icons.Filled.PowerSettingsNew, "Power", bg = C.RedBg, tint = C.Red) { remote.key(Key.POWER) }
            LabeledKey(Icons.Filled.Input, "Input") { remote.key(Key.INPUT) }
            LabeledKey(Icons.Filled.Search, "Cari") { remote.key(Key.SEARCH) }
            LabeledKey(Icons.Filled.Menu, "Menu") { remote.key(Key.MENU) }
        }

        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            DPad(232.dp) { remote.key(it) }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            LabeledKey(Icons.Filled.ArrowBack, "Kembali") { remote.key(Key.BACK) }
            LabeledKey(Icons.Filled.Home, "Beranda") { remote.key(Key.HOME) }
            LabeledKey(Icons.Filled.PlayArrow, "Putar/Jeda") { remote.key(Key.PLAY_PAUSE) }
        }

        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Pill(
                Modifier.weight(1f), "VOL",
                Icons.Filled.Remove, "Volume turun", { remote.key(Key.VOL_DOWN) },
                Icons.Filled.Add, "Volume naik", { remote.key(Key.VOL_UP) }
            )
            RoundKey(Icons.Filled.VolumeOff, "Bisukan") { remote.key(Key.MUTE) }
            Pill(
                Modifier.weight(1f), "CH",
                Icons.Filled.KeyboardArrowDown, "Channel turun", { remote.key(Key.CH_DOWN) },
                Icons.Filled.KeyboardArrowUp, "Channel naik", { remote.key(Key.CH_UP) }
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Pintasan", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = C.Text)
                Spacer(Modifier.weight(1f))
                Text(
                    "Atur", color = C.Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onOpenShortcuts).padding(8.dp)
                )
            }
            val cells: List<Shortcut?> = shortcuts + listOf<Shortcut?>(null)
            if (grid) {
                cells.chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { sc ->
                            ShortcutTile(sc, Modifier.weight(1f)) {
                                if (sc == null) onAddShortcut() else remote.runShortcut(sc)
                            }
                        }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(cells) { sc ->
                        ShortcutTile(sc, Modifier.width(66.dp)) {
                            if (sc == null) onAddShortcut() else remote.runShortcut(sc)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceChip(remote: RemoteClient, onClick: () -> Unit) {
    val state by remote.state.collectAsState()
    val name by remote.deviceName.collectAsState()
    val (label, color) = statusOf(state)
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(C.Surface)
            .border(1.dp, C.Border, RoundedCornerShape(50)).clickable(onClick = onClick)
            .padding(start = 6.dp, end = 14.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(Modifier.size(34.dp).clip(CircleShape).background(C.Surface2), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Tv, null, tint = C.Text, modifier = Modifier.size(18.dp))
        }
        Column {
            Text(name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = C.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(label, fontSize = 11.sp, color = color, maxLines = 1)
        }
        Icon(Icons.Filled.KeyboardArrowDown, null, tint = C.Muted, modifier = Modifier.size(16.dp))
    }
}

@Composable
fun Pill(
    modifier: Modifier,
    label: String,
    leftIcon: ImageVector, leftDesc: String, onLeft: () -> Unit,
    rightIcon: ImageVector, rightDesc: String, onRight: () -> Unit
) {
    Row(
        modifier.height(56.dp).clip(RoundedCornerShape(50)).background(C.Surface)
            .border(1.dp, C.Border, RoundedCornerShape(50)).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PressBox(Modifier.size(44.dp).clip(CircleShape).background(C.Surface2), leftDesc, true, onLeft) {
            Icon(leftIcon, null, tint = C.Text, modifier = Modifier.size(20.dp))
        }
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Text(label, color = C.Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp)
        }
        PressBox(Modifier.size(44.dp).clip(CircleShape).background(C.Surface2), rightDesc, true, onRight) {
            Icon(rightIcon, null, tint = C.Text, modifier = Modifier.size(20.dp))
        }
    }
}
