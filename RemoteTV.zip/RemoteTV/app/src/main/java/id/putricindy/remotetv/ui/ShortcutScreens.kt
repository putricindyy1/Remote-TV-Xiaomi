package id.putricindy.remotetv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.putricindy.remotetv.RemoteApp
import id.putricindy.remotetv.data.APP_PRESETS
import id.putricindy.remotetv.data.ICON_NAMES
import id.putricindy.remotetv.data.KEY_OPTIONS
import id.putricindy.remotetv.data.PALETTE
import id.putricindy.remotetv.data.Shortcut
import id.putricindy.remotetv.data.Step
import id.putricindy.remotetv.data.delayLabel
import id.putricindy.remotetv.data.describe
import id.putricindy.remotetv.data.subtitle
import java.util.UUID

@Composable
private fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        RoundKey(Icons.Filled.ArrowBack, "Kembali", size = 44.dp, onClick = onBack)
        Text(
            title, color = C.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 14.dp)
        )
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = C.Accent,
    unfocusedBorderColor = C.Border,
    focusedTextColor = C.Text,
    unfocusedTextColor = C.Text,
    cursorColor = C.Accent
)

@Composable
fun ShortcutsScreen(app: RemoteApp, onBack: () -> Unit, onEdit: (String) -> Unit) {
    val list by app.store.items.collectAsState()
    val grid by app.prefs.grid.collectAsState()
    var toDelete by remember { mutableStateOf<Shortcut?>(null) }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        TopBar("Atur Pintasan", onBack)
        SectionLabel("TAMPILAN DI REMOTE")
        Segmented(listOf("Baris geser", "Grid 4 kolom"), if (grid) 1 else 0) { app.prefs.setGrid(it == 1) }
        SectionLabel("PINTASAN AKTIF")
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(list, key = { _, s -> s.id }) { i, s ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.Surface)
                        .border(1.dp, C.Border, RoundedCornerShape(16.dp))
                        .clickable { app.remote.runShortcut(s) }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val col = Color(s.color)
                    Box(
                        Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(col.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center
                    ) { Icon(iconFor(s.icon), null, tint = col, modifier = Modifier.size(20.dp)) }
                    Column(Modifier.weight(1f)) {
                        Text(s.name, color = C.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(s.subtitle(), color = C.Muted, fontSize = 12.sp)
                    }
                    SmallIcon(Icons.Filled.ArrowUpward, "Naikkan", enabled = i > 0) { app.store.move(s.id, -1) }
                    SmallIcon(Icons.Filled.ArrowDownward, "Turunkan", enabled = i < list.size - 1) { app.store.move(s.id, 1) }
                    SmallIcon(Icons.Filled.Edit, "Ubah") { onEdit(s.id) }
                    SmallIcon(Icons.Filled.Delete, "Hapus") { toDelete = s }
                }
            }
        }
        Button(
            onClick = { onEdit("") },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(50),
            colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)
        ) {
            Icon(Icons.Filled.Add, null)
            Spacer(Modifier.width(8.dp))
            Text("Tambah pintasan", fontWeight = FontWeight.Bold)
        }
    }

    val del = toDelete
    if (del != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Hapus \"${del.name}\"?") },
            text = { Text("Pintasan ini akan hilang dari remote.") },
            confirmButton = {
                TextButton(onClick = {
                    app.store.delete(del.id)
                    toDelete = null
                }) { Text("Hapus", color = C.Red) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Batal") } },
            containerColor = C.Surface
        )
    }
}

@Composable
private fun SmallIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, enabled: Boolean = true, onClick: () -> Unit) {
    PressBox(
        Modifier.size(36.dp).clip(CircleShape).then(if (enabled) Modifier else Modifier),
        desc, false, { if (enabled) onClick() }
    ) {
        Icon(icon, null, tint = if (enabled) C.Muted else C.Border, modifier = Modifier.size(18.dp))
    }
}

private val DELAY_CHOICES = listOf(1L, 2L, 5L, 10L, 30L, 60L, 300L, 900L, 1800L, 3600L)

@Composable
fun ShortcutEditScreen(app: RemoteApp, id: String?, onClose: () -> Unit) {
    val existing = remember(id) { id?.let { i -> app.store.items.value.firstOrNull { it.id == i } } }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var icon by remember { mutableStateOf(existing?.icon ?: "star") }
    var color by remember { mutableStateOf(existing?.color ?: PALETTE[2]) }
    val steps = remember { mutableStateListOf<Step>().apply { existing?.let { addAll(it.steps) } } }
    var dialog by remember { mutableStateOf("") }

    fun build(): Shortcut = Shortcut(
        id = existing?.id ?: UUID.randomUUID().toString(),
        name = name.trim().ifEmpty { steps.firstOrNull()?.describe() ?: "Pintasan" },
        icon = icon,
        color = color,
        steps = steps.toList()
    )

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
        TopBar(if (existing == null) "Pintasan Baru" else "Ubah Pintasan", onClose)
        Spacer(Modifier.height(16.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                SectionLabel("NAMA")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("mis. Mode Tidur") },
                    colors = fieldColors()
                )
            }
            item {
                SectionLabel("IKON & WARNA")
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ICON_NAMES.forEach { n ->
                        val on = n == icon
                        Box(
                            Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
                                .background(Color(color).copy(alpha = 0.18f))
                                .border(if (on) 2.dp else 1.dp, if (on) C.Accent else C.Border, RoundedCornerShape(14.dp))
                                .clickable { icon = n },
                            contentAlignment = Alignment.Center
                        ) { Icon(iconFor(n), null, tint = Color(color)) }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PALETTE.forEach { c ->
                        Box(
                            Modifier.size(32.dp).clip(CircleShape).background(Color(c))
                                .border(if (c == color) 3.dp else 0.dp, C.Text, CircleShape)
                                .clickable { color = c }
                        )
                    }
                }
            }
            item {
                SectionLabel("LANGKAH (DIJALANKAN BERURUTAN)")
            }
            itemsIndexed(steps) { i, st ->
                Row(
                    Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(14.dp)).background(C.Surface)
                        .border(1.dp, C.Border, RoundedCornerShape(14.dp)).padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(Modifier.size(26.dp).clip(CircleShape).background(C.Surface2), contentAlignment = Alignment.Center) {
                        Text("${i + 1}", color = C.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(st.describe(), color = C.Text, fontSize = 14.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    SmallIcon(Icons.Filled.ArrowUpward, "Naikkan", enabled = i > 0) {
                        val t = steps[i]; steps[i] = steps[i - 1]; steps[i - 1] = t
                    }
                    SmallIcon(Icons.Filled.Close, "Hapus langkah") { steps.removeAt(i) }
                }
            }
            item {
                SectionLabel("TAMBAH LANGKAH")
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Tombol", Icons.Filled.SettingsRemote) { dialog = "KEY" }
                    Chip("Jeda", Icons.Filled.Timer) { dialog = "DELAY" }
                    Chip("Buka aplikasi", Icons.Filled.Apps) { dialog = "APP" }
                    Chip("Ketik teks", Icons.Filled.TextFields) { dialog = "TEXT" }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = { if (steps.isNotEmpty()) app.remote.runShortcut(build()) },
                modifier = Modifier.weight(1f).height(52.dp),
                shape = RoundedCornerShape(50)
            ) { Text("Coba di TV", color = C.Text) }
            Button(
                onClick = {
                    app.store.upsert(build())
                    onClose()
                },
                enabled = steps.isNotEmpty(),
                modifier = Modifier.weight(1f).height(52.dp),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)
            ) { Text("Simpan", fontWeight = FontWeight.Bold) }
        }
    }

    when (dialog) {
        "KEY" -> KeyDialog(onDismiss = { dialog = "" }) { code, rep ->
            steps.add(Step("KEY", code = code, repeat = rep)); dialog = ""
        }
        "DELAY" -> PickDialog("Pilih lama jeda", DELAY_CHOICES.map { delayLabel(it * 1000) }, onDismiss = { dialog = "" }) { i ->
            steps.add(Step("DELAY", ms = DELAY_CHOICES[i] * 1000)); dialog = ""
        }
        "APP" -> AppDialog(onDismiss = { dialog = "" }) { link ->
            steps.add(Step("APP", text = link)); dialog = ""
        }
        "TEXT" -> TextDialog(onDismiss = { dialog = "" }) { t ->
            steps.add(Step("TEXT", text = t)); dialog = ""
        }
    }
}

@Composable
private fun KeyDialog(onDismiss: () -> Unit, onPick: (Int, Int) -> Unit) {
    var rep by remember { mutableStateOf(1) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pilih tombol") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Tekan sebanyak", color = C.Muted, modifier = Modifier.weight(1f))
                    SmallIcon(Icons.Filled.Remove, "Kurangi") { if (rep > 1) rep -= 1 }
                    Text("$rep×", color = C.Text, fontWeight = FontWeight.Bold)
                    SmallIcon(Icons.Filled.Add, "Tambah") { if (rep < 20) rep += 1 }
                }
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(KEY_OPTIONS) { k ->
                        Text(
                            k.label, color = C.Text, fontSize = 15.sp,
                            modifier = Modifier.fillMaxWidth().clickable { onPick(k.code, rep) }.padding(vertical = 12.dp)
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        containerColor = C.Surface
    )
}

@Composable
private fun PickDialog(title: String, options: List<String>, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                itemsIndexed(options) { i, o ->
                    Text(
                        o, color = C.Text, fontSize = 15.sp,
                        modifier = Modifier.fillMaxWidth().clickable { onPick(i) }.padding(vertical = 12.dp)
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        containerColor = C.Surface
    )
}

@Composable
private fun AppDialog(onDismiss: () -> Unit, onPick: (String) -> Unit) {
    var custom by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Buka aplikasi") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                APP_PRESETS.forEach { p ->
                    Text(
                        p.label, color = C.Text, fontSize = 15.sp,
                        modifier = Modifier.fillMaxWidth().clickable { onPick(p.link) }.padding(vertical = 10.dp)
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text("Aplikasi lain: market://launch?id=nama.paket.aplikasi", color = C.Muted, fontSize = 12.sp)
                OutlinedTextField(
                    value = custom, onValueChange = { custom = it.trim() },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Tautan atau nama paket") },
                    colors = fieldColors()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val link = if (custom.contains(":")) custom else "market://launch?id=$custom"
                    if (custom.isNotEmpty()) onPick(link)
                }
            ) { Text("Tambah") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        containerColor = C.Surface
    )
}

@Composable
private fun TextDialog(onDismiss: () -> Unit, onPick: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ketik teks") },
        text = {
            OutlinedTextField(
                value = t, onValueChange = { t = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("mis. lagu anak") },
                colors = fieldColors()
            )
        },
        confirmButton = { TextButton(onClick = { if (t.isNotEmpty()) onPick(t) }) { Text("Tambah") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        containerColor = C.Surface
    )
}
